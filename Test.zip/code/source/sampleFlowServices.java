

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class sampleFlowServices

{
	// ---( internal utility methods )---

	final static sampleFlowServices _instance = new sampleFlowServices();

	static sampleFlowServices _newInstance() { return new sampleFlowServices(); }

	static sampleFlowServices _cast(Object o) { return (sampleFlowServices)o; }

	// ---( server methods )---




	public static final void SamplejavaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(SamplejavaService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required Num1
		// [i] field:0:required Num2
		// [o] field:0:required Result
		// --- <<IS-END>> ---

                
	}



	public static final void TestJavaservice (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(TestJavaservice)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

